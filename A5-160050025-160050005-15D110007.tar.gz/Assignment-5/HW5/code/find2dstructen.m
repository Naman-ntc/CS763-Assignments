function [ output ] = find2dstructen( image,point,Xgrads,Ygrads)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

output = zeros(2,2);

bbox = 81;
mp = floor(bbox/2);

for i = point(1)-mp:point(1)+mp
    for j = point(2)-mp:point(2)+mp
        deltaI = [Xgrads(i,j) , Ygrads(i,j)];
        temp = double(deltaI);
        output = output + transpose(temp) * temp;
    end
end

end